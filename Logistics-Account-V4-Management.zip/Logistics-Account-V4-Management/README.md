# Logistics Account V4 - Management Dashboard

This build uses the supplied JA Accounting dashboard design as the management UI.

Included:
- Management-style dark sidebar
- Dashboard cards and charts
- Transactions
- Accounts
- Statements
- Journal Accounts with debit/credit balancing
- Reports
- Staff Management (Admin view)
- Settings and Help
- Responsive mobile sidebar
- Browser localStorage for prototype data

Open index.html in a browser. This is a frontend prototype; production authentication, database, password recovery, PDF/Excel export and server-side security still need a backend.
